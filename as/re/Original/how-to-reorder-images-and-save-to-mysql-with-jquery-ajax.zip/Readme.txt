Author: Yogesh singh
Author URL: https://makitweb.com/
Author Email: makitweb@gmail.com
Tutorial Link: https://makitweb.com/how-to-reorder-images-and-save-to-mysql-with-jquery-ajax/


######
1. Update database configuration in config.php
2. Import attached images_list.sql file in your database.